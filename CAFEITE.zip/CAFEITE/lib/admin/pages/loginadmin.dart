// //KODE INI HANYA SIMULASI SILAHKAN DI UBAH
// // ignore_for_file: unused_import

// import 'package:cafeite/cust/pages/register.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:firebase_auth/firebase_auth.dart';

// import 'package:cafeite/admin/pages/home_admin.dart'; // Pastikan Anda mengimpor HomeScreen
// import 'package:cafeite/cust/pages/home_user.dart'; // Pastikan Anda mengimpor HomeScreenUser
// import 'package:cafeite/cust/pages/login.dart';

// class LoginadminPage extends StatefulWidget {
//   @override
//   _LoginadminPageState createState() => _LoginadminPageState();
// }

// class _LoginadminPageState extends State<LoginadminPage> {
//   final TextEditingController emailController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();
//   final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
//   bool isLoading = false;

//   Future<void> _loginAdmin() async {
//     if (_formKey.currentState!.validate()) {
//       setState(() {
//         isLoading = true;
//       });

//       try {
//         // Firebase Authentication login
//         UserCredential userCredential =
//             await FirebaseAuth.instance.signInWithEmailAndPassword(
//           email: emailController.text.trim(),
//           password: passwordController.text.trim(),
//         );

//         // Check if user is admin
//         // Assume admin has a specific email (e.g., admin@example.com)
//         if (userCredential.user != null &&
//             emailController.text.trim() == 'admin@example.com') {
//           // Save login state using SharedPreferences
//           SharedPreferences prefs = await SharedPreferences.getInstance();
//           await prefs.setBool('isLoggedIn', true);
//           await prefs.setString('userRole', 'admin');

//           // Navigate to admin home page
//           Navigator.pushReplacement(
//             context,
//             MaterialPageRoute(builder: (context) => HomePageAdmin()),
//           );
//         } else {
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(content: Text('Hanya admin yang dapat login di sini')),
//           );
//         }
//       } on FirebaseAuthException catch (e) {
//         String message;
//         if (e.code == 'user-not-found') {
//           message = 'Pengguna tidak ditemukan.';
//         } else if (e.code == 'wrong-password') {
//           message = 'Password salah.';
//         } else {
//           message = 'Terjadi kesalahan. Silakan coba lagi.';
//         }
//         ScaffoldMessenger.of(context)
//             .showSnackBar(SnackBar(content: Text(message)));
//       } finally {
//         setState(() {
//           isLoading = false;
//         });
//       }
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Login Admin'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Form(
//           key: _formKey,
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               TextFormField(
//                 controller: emailController,
//                 keyboardType: TextInputType.emailAddress,
//                 decoration: InputDecoration(
//                   labelText: 'Email',
//                   border: OutlineInputBorder(),
//                 ),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Email tidak boleh kosong';
//                   } else if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
//                     return 'Format email tidak valid';
//                   }
//                   return null;
//                 },
//               ),
//               SizedBox(height: 16),
//               TextFormField(
//                 controller: passwordController,
//                 obscureText: true,
//                 decoration: InputDecoration(
//                   labelText: 'Password',
//                   border: OutlineInputBorder(),
//                 ),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Password tidak boleh kosong';
//                   } else if (value.length < 6) {
//                     return 'Password minimal 6 karakter';
//                   }
//                   return null;
//                 },
//               ),
//               SizedBox(height: 20),
//               isLoading
//                   ? CircularProgressIndicator()
//                   : ElevatedButton(
//                       onPressed: _loginAdmin,
//                       child: Text('Login'),
//                     ),
//               SizedBox(height: 20),
//               TextButton(
//                 onPressed: () {
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(builder: (context) => RegisterPage()),
//                   );
//                 },
//                 child: Text('Belum punya akun? Daftar di sini'),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

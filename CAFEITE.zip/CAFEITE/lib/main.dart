//992024008 - Nurmei Sarrah
//992024007 - Zilfany
//992024006 - Masyitah Nanda Yassril
//162022030 - Gilang Ramadhan

// ignore_for_file: unused_import, duplicate_import

import 'package:cafeite/cust/pages/cart_provider.dart';
import 'package:cafeite/cust/pages/home_user.dart';
import 'package:cafeite/admin/pages/home_admin.dart';
import 'package:cafeite/cust/pages/login.dart';
import 'package:cafeite/cust/pages/register.dart';
import 'package:cafeite/pages/landingpage.dart';
import 'package:cafeite/pages/landingpage.dart';
import 'package:device_preview/device_preview.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';

import 'package:flutter/material.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(
    DevicePreview(
      enabled: !kReleaseMode,
      builder: (context) => MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => CartProvider()),
        ],
        child: const MyApp(),
      ),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'cafeITe',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: AuthWrapper(),
      routes: {
        'home_admin': (context) => HomePageAdmin(),
        'home_user': (context) => HomePageUser(),
        'login_page': (context) => LoginPage(),
      },
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        // Jika masih loading
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        // Jika sudah login
        if (snapshot.hasData) {
          // Cek apakah user adalah admin
          if (snapshot.data!.email == 'admin@gmail.com') {
            return const HomePageAdmin();
          }
          // Jika bukan admin, arahkan ke halaman user
          return const HomePageUser();
        }

        // Jika belum login
        return LoginPage();
      },
    );
  }
}
